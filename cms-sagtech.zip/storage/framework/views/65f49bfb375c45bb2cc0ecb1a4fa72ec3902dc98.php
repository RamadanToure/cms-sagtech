<div class="modal-content">
	<div class="modal-body text-center p-4">
		<div class="mt-2">
			<h4 class="mb-3" >Voulez-vous vraiment transmettre le courrier à l'expéditeur <?php echo e($expediteur); ?> ?</h4>
			<br>
			<form action="<?php echo e(url('courrier/confirmer/'.$item->id_cour)); ?>" method="POST">
				<?php echo csrf_field(); ?>
				<button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Non</button>
				<button id="submit" class="btn btn-warning rounded-pill">Oui</button>
			</form>
			<div class="hstack gap-2 justify-content-center"></div>
		</div>
	</div>
</div>
<?php /**PATH C:\wamp64\www\SAGTECH\app_csm\resources\views/courrier/confirmer.blade.php ENDPATH**/ ?>