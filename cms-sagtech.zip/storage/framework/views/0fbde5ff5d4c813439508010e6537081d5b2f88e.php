<title><?php echo e(Config('app.name')); ?> | Courrier sortant</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php echo trans('data.stylePdf'); ?> 
<div class="footer"><i><?php echo trans('data.signaturePdf'); ?> <span class="pagenum"></span> </i></div>

<?php if(count($list) != 0): ?>
	<div><h3 style="text-align:center;">Courrier sortant<br>
		<?php if(!empty($_GET['query'])): ?>
			Recherche : <?php echo e($_GET['query']); ?><br>
		<?php endif; ?>
	</h3></div>

	<table class="table" style="font-size:15px; width:100%;">
		<tr>
			<th class="th" ><?php echo trans('data.ref_cour'); ?></th>
			<th class="th" ><?php echo trans('data.code_cour'); ?></th>
			<th class="th" ><?php echo trans('data.date_envoi'); ?></th>
			<th class="th" ><?php echo trans('data.sujet_cour'); ?></th>
			<th class="th" ><?php echo trans('data.note_cour'); ?></th>
			<th class="th" ><?php echo trans('data.piece_jointe'); ?></th>
			<th class="th" ><?php echo trans('data.dest_id'); ?></th>
			<th class="th" ><?php echo trans('data.direc_id'); ?></th>
			<th class="th" ><?php echo trans('data.init_id'); ?></th>
		</tr>
		<tbody><?php echo e($i = 1); ?>

			<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listgiwu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr style="background-color : <?php if ($i % 2 == 0) {echo '#ffffff';$i++;}else{echo trans("data.styleLignePdf");$i++;} ?>;">
					<td class="td"><?php echo e($listgiwu->ref_cour); ?></td>
					<td class="td"><?php echo e($listgiwu->code_cour); ?></td>
					<td class="td"><?php echo e($listgiwu->date_envoi); ?></td>
					<td class="td"><?php echo e($listgiwu->sujet_cour); ?></td>
					<td class="td"><?php echo e($listgiwu->note_cour); ?></td>
					<td class="td"><?php echo e($listgiwu->piece_jointe); ?></td>
					<td class="td"><?php echo e(isset($listgiwu->expediteur) ? $listgiwu->expediteur->nom_expe : trans('data.not_found')); ?></td>
					<td class="td"><?php echo e(isset($listgiwu->direction) ? $listgiwu->direction->code_direc : trans('data.not_found')); ?></td>
					<td class="td"><?php echo e(isset($listgiwu->users_g) ? $listgiwu->users_g->name." ".$listgiwu->users_g->prenom : trans('data.not_found')); ?></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
<?php else: ?>
	<div><strong>Info! </strong> <?php echo trans('data.AucunInfosTrouve'); ?> </div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\SAGTECH\app_csm\resources\views/courriersortant/pdf.blade.php ENDPATH**/ ?>