

<?php $__env->startSection('path_content'); ?>
	<?php if(sizeof($pathMenu) != 0): ?>
		<?php for($i=0; $i < count($pathMenu); $i++): ?>
      <li class="breadcrumb-item active"><a href="<?php echo e($pathMenu[$i]['lien']); ?>" class="kt-subheader__breadcrumbs-link"><?php echo e($pathMenu[$i]['titre']); ?></a></li>
		<?php endfor; ?>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
  <iframe src="<?php echo e(url('/assets/docs/logos/'.$societe->pdf_aide)); ?>" height="600px"></iframe>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SAGTECH\app_csm\resources\views/layouts/containHelp.blade.php ENDPATH**/ ?>