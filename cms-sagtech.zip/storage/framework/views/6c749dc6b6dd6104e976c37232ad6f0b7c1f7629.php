<title><?php echo e(Config('app.name')); ?> | Retraite</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php echo trans('data.stylePdf'); ?> 
<div class="footer"><i><?php echo trans('data.signaturePdf'); ?> <span class="pagenum"></span> </i></div>

<?php if(count($list) != 0): ?>
	<div><h3 style="text-align:center;">Retraite<br>
		<?php if(!empty($_GET['query'])): ?>
			Recherche : <?php echo e($_GET['query']); ?><br>
		<?php endif; ?>
	</h3></div>

	<table class="table" style="font-size:15px; width:100%;">
		<tr>
			<th class="th" ><?php echo trans('data.matricule'); ?></th>
			<th class="th" ><?php echo trans('data.name'); ?></th>
			<th class="th" ><?php echo trans('data.prenom'); ?></th>
			<th class="th" ><?php echo trans('data.email'); ?></th>
			<th class="th" ><?php echo trans('data.grade'); ?></th>
			<th class="th" ><?php echo trans('data.echellon'); ?></th>
			<th class="th" ><?php echo trans('data.date_embauche'); ?></th>
			<th class="th" ><?php echo trans('data.date_nais'); ?></th>
			<th class="th" ><?php echo trans('data.init_id'); ?></th>
			<th class="th" ><?php echo trans('data.id_role'); ?></th>
			<th class="th" ><?php echo trans('data.tel_user'); ?></th>
		</tr>
		<tbody><?php echo e($i = 1); ?>

			<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listgiwu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr style="background-color : <?php if ($i % 2 == 0) {echo '#ffffff';$i++;}else{echo trans("data.styleLignePdf");$i++;} ?>;">
					<td class="td"><?php echo e($listgiwu->matricule); ?></td>
					<td class="td"><?php echo e($listgiwu->name); ?></td>
					<td class="td"><?php echo e($listgiwu->prenom); ?></td>
					<td class="td"><?php echo e($listgiwu->email); ?></td>
					<td class="td"><?php echo e($listgiwu->grade); ?></td>
					<td class="td"><?php echo e($listgiwu->echellon); ?></td>
					<td class="td"><?php echo e(date('d/m/Y',strtotime($listgiwu->date_embauche))); ?></td>
					<td class="td"><?php echo e(date('d/m/Y',strtotime($listgiwu->date_nais))); ?></td>
					<td class="td"><?php echo e(isset($listgiwu->users_g) ? $listgiwu->users_g->name." ".$listgiwu->users_g->prenom : trans('data.not_found')); ?></td>
					<td class="td"><?php echo e(isset($listgiwu->service) ? $listgiwu->service->code_serv : trans('data.not_found')); ?></td>
					<td class="td"><?php echo e($listgiwu->tel_user); ?></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
<?php else: ?>
	<div><strong>Info! </strong> <?php echo trans('data.AucunInfosTrouve'); ?> </div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\SAGTECH\app_csm\resources\views/cons/listretraite/pdf.blade.php ENDPATH**/ ?>