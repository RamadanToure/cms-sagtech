<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php if(count($list) != 0): ?>
	<table class="table table-striped table-bordered table-nowrap">
		<thead><tr>
			<th scope="col" ><?php echo trans('data.matricule'); ?></th>
			<th scope="col" ><?php echo trans('data.name'); ?></th>
			<th scope="col" ><?php echo trans('data.prenom'); ?></th>
			<th scope="col" ><?php echo trans('data.email'); ?></th>
			<th scope="col" ><?php echo trans('data.grade'); ?></th>
			<th scope="col" ><?php echo trans('data.echellon'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.date_embauche'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.date_nais'); ?></th>
			<!-- <th scope="col" ><?php echo trans('data.init_id'); ?></th> -->
		</tr></thead>
		<tbody>
			<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listgiwu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo $listgiwu->matricule; ?></td>
					<td><?php echo $listgiwu->name; ?></td>
					<td><?php echo $listgiwu->prenom; ?></td>
					<td><?php echo $listgiwu->email; ?></td>
					<td><?php echo $listgiwu->grade; ?></td>
					<td><?php echo $listgiwu->echellon; ?></td>
					<td class="text-center"><?php echo e(date('d/m/Y',strtotime($listgiwu->date_embauche))); ?></td>
					<td class="text-center"><?php echo e(date('d/m/Y',strtotime($listgiwu->date_nais))); ?></td>
					<!-- <td><?php echo isset($listgiwu->users_g) ? $listgiwu->users_g->name." ".$listgiwu->users_g->prenom : trans('data.not_found'); ?></td> -->
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	
	<?php echo $list->appends(['query'=>(isset($_GET['query'])?$_GET['query']:'') ])->links(); ?>

<?php else: ?>
	<div Class="alert alert-info"><strong>Info! </strong> <?php echo trans('data.AucunInfosTrouve'); ?> </div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\SAGTECH\app_csm\resources\views/cons/listretraite/index-search.blade.php ENDPATH**/ ?>