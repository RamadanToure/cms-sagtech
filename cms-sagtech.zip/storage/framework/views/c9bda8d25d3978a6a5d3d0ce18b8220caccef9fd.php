<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php if(count($list) != 0): ?>
	<table class="table table-striped table-bordered table-nowrap">
		<thead><tr>
			<?php if(in_array('update_courriersortant',session('InfosAction')) || in_array('delete_courriersortant',session('InfosAction')) ): ?>
				<th class="text-center"> Actions</th>
			<?php endif; ?>
			<th scope="col" ><?php echo trans('data.ref_cour'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.piece_jointe'); ?></th>
			<th scope="col" ><?php echo trans('data.date_envoi'); ?></th>
			<th scope="col" ><?php echo trans('data.sujet_cour'); ?></th>
			<th scope="col" ><?php echo trans('data.note_cour'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.dest_id'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.direc_id'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.init_id'); ?></th>
		</tr></thead>
		<tbody>
			<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listgiwu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<?php if(in_array('update_courriersortant',session('InfosAction')) || in_array('delete_courriersortant',session('InfosAction')) ): ?>
						<td class="text-center">
							<?php if(in_array('update_courriersortant',session('InfosAction'))): ?>
								<a href="<?php echo e(route('courriersortant.edit',$listgiwu->id_cours)); ?>" title='Modifier' class="btn btn-success btn-sm  waves-effect waves-light"><i class="ri-edit-2-line"></i></a>
							<?php endif; ?>
							<?php if(in_array('delete_courriersortant',session('InfosAction'))): ?>
								<button type="button"  title='Supprimer' data-id="<?php echo e($listgiwu->id_cours); ?>" class="btn btn-danger btn-sm  waves-effect waves-light btn-delete" data-bs-toggle="modal" ><i class="ri-delete-bin-6-line"></i></button>
							<?php endif; ?>
						</td>
					<?php endif; ?>
					<td><?php echo $listgiwu->ref_cour; ?></td>
					<td class="text-center">
						<?php if($listgiwu->piece_jointe): ?>
							<a href='<?php echo e("assets/courrier/".$listgiwu->piece_jointe); ?>' title="<?php echo $listgiwu->piece_jointe; ?>" target="_blank" class="badge bg-success">Ouvrir</a>
						<?php else: ?> <span class="badge bg-danger">Aucun</a>  <?php endif; ?>
					</td>
					<td><?php echo e(date('d/m/Y',strtotime($listgiwu->date_envoi))); ?></td>
					<td><?php echo $listgiwu->sujet_cour; ?></td>
					<td> <?php if(strlen($listgiwu->note_cour) > 30): ?>
						<?php echo substr($listgiwu->note_cour, 0, 30); ?>...
						<?php else: ?>  <?php echo $listgiwu->note_cour; ?> 
						<?php endif; ?> 
					</td>
					<td><?php echo isset($listgiwu->expediteur) ? $listgiwu->expediteur->nom_expe : trans('data.not_found'); ?></td>
					<td title="<?php echo e(isset($listgiwu->direction) ? $listgiwu->direction->lib_direc : trans('data.not_found')); ?>"><?php echo isset($listgiwu->direction) ? $listgiwu->direction->code_direc : trans('data.not_found'); ?></td>
					<td><?php echo isset($listgiwu->users_g) ? $listgiwu->users_g->name." ".$listgiwu->users_g->prenom : trans('data.not_found'); ?></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	
	<?php echo $list->appends(['query'=>(isset($_GET['query'])?$_GET['query']:'') ])->links(); ?>

<?php else: ?>
	<div Class="alert alert-info"><strong>Info! </strong> <?php echo trans('data.AucunInfosTrouve'); ?> </div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\SAGTECH\app_csm\resources\views/courriersortant/index-search.blade.php ENDPATH**/ ?>