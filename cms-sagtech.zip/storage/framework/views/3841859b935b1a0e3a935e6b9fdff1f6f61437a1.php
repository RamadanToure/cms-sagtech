
<div class="modal-content">
    <div class="modal-body text-center p-4">
        <div class="mt-2">
            <h4 class="mb-3 red-g" > <?php echo e(trans('data.titre_delete')); ?> <i class="bx bxs-trash"></i></h4>
            <p class="text-muted mb-4"> Voulez-vous vraiment supprimer <?php echo e($item->name." ".$item->prenom); ?> ? </p>
            <form  action="<?php echo e(route('users.destroy',$item->id)); ?>" method="POST">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Non</button>
                <button id="submit" class="btn btn-danger rounded-pill">Oui</button>
            </form>
            <div class="hstack gap-2 justify-content-center">
            </div>
        </div>
    </div>

</div>

<?php /**PATH C:\wamp64\www\SAGTECH\cms-sagtech\resources\views/users/delete.blade.php ENDPATH**/ ?>