<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12" style="text-align:center;">
                <span > <script>document.write(new Date().getFullYear())</script> © <?php echo e(Config('app.name')); ?>.</span>
            </div>
            <!-- <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    Design & Develop by <?php echo e(Config('app.name')); ?>

                </div>
            </div> -->
        </div>
    </div>
</footer><?php /**PATH C:\wamp64\www\SAGTECH\app_csm\resources\views/layouts/footer.blade.php ENDPATH**/ ?>