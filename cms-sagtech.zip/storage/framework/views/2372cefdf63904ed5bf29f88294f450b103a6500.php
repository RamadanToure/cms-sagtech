


<?php $__env->startSection('path_content'); ?>
	<?php if(sizeof($pathMenu) != 0): ?>
		<?php for($i=0; $i < count($pathMenu); $i++): ?>
            <li class="breadcrumb-item active"><a href="<?php echo e($pathMenu[$i]['lien']); ?>" class="kt-subheader__breadcrumbs-link"><?php echo e($pathMenu[$i]['titre']); ?></a></li>
		<?php endfor; ?>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1"><?php echo e($titre); ?></h4>
                <div class="flex-shrink-0">
                    <div class="form-check form-switch form-switch-right form-switch-md">
                        <i class="<?php echo e($icone); ?>"></i>
                    </div>
                </div>
            </div><!-- end card header -->
            <div class="card-body">
                <p class="text-muted"></p>
                <div class="live-preview">
                <strong><div class="msgAjouter"></div></strong>
                    <form action="<?php echo e(route('users.store')); ?>" method="post" id="form" class="row g-3 needs-validation" novalidate>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <?php if(session()->has('success') || session()->has('error')): ?>
                                <div class="col-md-12">
                                    <div class="alert <?php echo e(session()->has('success') ? 'alert-success' : ''); ?> <?php echo e(session()->has('error') ? 'alert-danger' : ''); ?> alert-border-left alert-dismissible fade show" role="alert">
                                        <i title ="<?php echo e(session()->has('errorMsg')? session()->get('errorMsg') : ''); ?>" class=" <?php echo e(session()->has('success') ? 'ri-notification-off-line' : 'ri-error-warning-line'); ?> me-3 align-middle"></i> <strong>Infos </strong> - <?php echo e(session()->has('success') ? session()->get('success') : session()->get('error')); ?>

                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="matricule" class="form-label"><?php echo e(trans('data.matricule')); ?><strong style='color: red;'> *</strong></label>
                                    <?php echo Form::text('matricule','',["id"=>"matricule","class"=>"form-control","required"=>"required",'placeholder'=>"Entrer votre grade",'autocomplete'=>'off']); ?>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="name" class="form-label"><?php echo e(trans('data.name')); ?><strong style='color: red;'> *</strong></label>
                                    <?php echo Form::text('name','',["id"=>"name","class"=>"form-control","required"=>"required",'placeholder'=>"Entrer votre nom",'autocomplete'=>'off']); ?>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="prenom" class="form-label"><?php echo e(trans('data.prenom')); ?><strong style='color: red;'> *</strong></label>
                                    <?php echo Form::text('prenom','',["id"=>"prenom","class"=>"form-control","required"=>"required",'placeholder'=>"Entrer votre prénom",'autocomplete'=>'off']); ?>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="tel_user" class="form-label"><?php echo e(trans('data.tel_user')); ?><strong style='color: red;'> *</strong></label>
                                    <?php echo Form::text('tel_user','',["id"=>"tel_user","class"=>"form-control","required"=>"required",'placeholder'=>"Entrer votre téléphone",'autocomplete'=>'off']); ?>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="email" class="form-label"><?php echo e(trans('data.email')); ?><strong style='color: red;'> *</strong></label>
                                    <?php echo Form::email('email','',["id"=>"email","class"=>"form-control","required"=>"required",'placeholder'=>"example@gamil.com",'autocomplete'=>'off']); ?>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="id_role" class="form-label"><?php echo e(trans('data.libelle_role')); ?><strong style='color: red;'> *</strong></label>
                                    <?php $addUse = array(''=>'Sélectionner un élément'); $sltRole = $addUse + $sltRole->toArray();?>
						            <?php echo Form::select('id_role',$sltRole ,null,["id"=>"id_role","class"=>"form-select select2",'required'=>'required']); ?>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="is_active" class="form-label"><?php echo e(trans('data.is_active')); ?><strong style='color: red;'> *</strong></label>
                                    <?php $addUse = array(''=>'Sélectionner un élément','1'=>'Activé','0'=>'Désactivé');?>
                                    <?php echo Form::select('is_active',$addUse ,null,["id"=>"is_active","class"=>"form-select select2",'required'=>'required']); ?>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="type_fonct" class="form-label"><?php echo e(trans('data.type_fonct')); ?><strong style='color: red;'> *</strong></label>
						            <?php echo Form::select('type_destina',trans('entite.type_destinataire') ,null,["id"=>"type_destina","class"=>"form-select select2",'required'=>'required']); ?>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="id_fonct" class="form-label"><?php echo e(trans('data.id_fonct')); ?><strong style='color: red;'> *</strong></label>
                                    <?php echo Form::select('id_desti',[],null,["id"=>"id_desti","class"=>"form-select allselect","required"=>"required"]); ?>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="grade" class="form-label"><?php echo e(trans('data.grade')); ?></label>
                                    <?php echo Form::text('grade','',["id"=>"grade","class"=>"form-control",'placeholder'=>"Entrer votre grade",'autocomplete'=>'off']); ?>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="echellon" class="form-label"><?php echo e(trans('data.echellon')); ?></label>
                                    <?php echo Form::text('echellon','',["id"=>"echellon","class"=>"form-control",'placeholder'=>"Entrer votre grade",'autocomplete'=>'off']); ?>

                                </div>
                            </div>
                            <div class="col-md-4">
								<div class="mb-3">
									<label for="date_nais" class="form-label"><?php echo trans('data.date_nais'); ?> <strong style='color: red;'> *</strong></label>
									<?php echo Form::date('date_nais',date('Y-m-d'),["id"=>"date_nais","class"=>"form-control" ,"required"=>"required" ,'autocomplete'=>'off' ,'placeholder'=>"Entrer Date debut" ]); ?>

								</div>
							</div>
                            <div class="col-md-4">
								<div class="mb-3">
									<label for="date_embauche" class="form-label"><?php echo trans('data.date_embauche'); ?> <strong style='color: red;'> *</strong></label>
									<?php echo Form::date('date_embauche',date('Y-m-d'),["id"=>"date_embauche","class"=>"form-control" ,"required"=>"required" ,'autocomplete'=>'off' ,'placeholder'=>"Entrer Date debut" ]); ?>

								</div>
							</div>
                            <div class="col-md-8">
                                <div class="mb-3">
                                    <label for="other_infos_user" class="form-label"><?php echo e(trans('data.other_infos_user')); ?></label>
                                    <?php echo Form::text('other_infos_user','',["id"=>"other_infos_user","class"=>"form-control",'placeholder'=>"Entrer votre d'autre informations",'autocomplete'=>'off']); ?>

                                </div>
                            </div>
                            <div class="col-12">
                                <div class="text-end">
                                    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-outline-dark waves-effect mr-10 rounded-pill">Fermer</a>
                                    <?php if(in_array('add_user',session('InfosAction'))): ?>
                                        <button type="submit" class="btn btn-primary btn-label right rounded-pill"><i class="ri-add-line label-icon align-middle fs-16 ms-2 rounded-pill"></i>Ajouter</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div><!--end row-->
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('JS_content'); ?>
	<script src="<?php echo e(url('assets/js/jquery.min.js')); ?>" type="text/javascript"></script>

    <script type="text/javascript">

	// Écoutez les changements dans le premier combo(combo1)
	document.getElementById("type_destina").addEventListener("change", function() {
		ChargeDestinataire();
	});

</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SAGTECH\cms-sagtech\resources\views/users/create.blade.php ENDPATH**/ ?>