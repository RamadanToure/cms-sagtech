

<?php $__env->startSection('path_content'); ?>
	<?php if(sizeof($pathMenu) != 0): ?>
		<?php for($i=0; $i < count($pathMenu); $i++): ?>
			<li class="breadcrumb-item active"><a href="<?php echo e($pathMenu[$i]['lien']); ?>" class="kt-subheader__breadcrumbs-link"><?php echo e($pathMenu[$i]['titre']); ?></a></li>
		<?php endfor; ?>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="col-lg-12">
		<div class="card">
			<div class="card-header align-items-center d-flex">
				<h4 class="card-title mb-0 flex-grow-1"><?php echo e($titre); ?></h4>
				<div class="flex-shrink-0"><div class="form-check form-switch form-switch-right form-switch-md"><i class="<?php echo e($icone); ?>"></i></div></div>
			</div><!-- end card header -->
			<div class="card-body"><p class="text-muted"></p>
				<div class="live-preview"><strong><div class="msgAjouter"></div></strong>
					<form action="<?php echo e(route('carriere.update',$item->id_carr)); ?>" method="post" id="form" class="row g-3 needs-validation" novalidate >
						<?php echo csrf_field(); ?>
						<?php echo method_field('PATCH'); ?>
							<div class="row">
							<?php if(session()->has('success') || session()->has('error')): ?><div class="col-md-12 mt-2"><div class="alert <?php echo session()->has('success') ? 'alert-success' : ''; ?> <?php echo session()->has('error') ? 'alert-danger' : ''; ?> alert-border-left alert-dismissible fade show" role="alert"><i title ="<?php echo session()->has('errorMsg')? session()->get('errorMsg') : ''; ?>" class=" <?php echo session()->has('success') ? 'ri-notification-off-line' : 'ri-error-warning-line'; ?> me-3 align-middle"></i> <strong>Infos </strong> - <?php echo session()->has('success') ? session()->get('success') : session()->get('error'); ?><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div></div><?php endif; ?>

							<div class="col-md-6">
								<div class="mb-3">
									<label for="type_fonct" class="form-label"><?php echo trans('data.type_fonct'); ?> <strong style='color: red;'> *</strong></label>
									<?php echo Form::select('type_fonct',trans('entite.type_destinataire') ,$item->type_fonct,["id"=>"type_destina","class"=>"form-select" ,"required"=>"required"]); ?>

								</div>
							</div>
							<div class="col-md-6">
								<div class="mb-3">
									<label for="id_fonct" class="form-label"><?php echo trans('data.id_fonct'); ?> <strong style='color: red;'> *</strong></label>
									<?php echo Form::select('id_fonct',$destina,$item->id_fonct,["id"=>"id_desti","class"=>"form-select allselect","required"=>"required"]); ?>

								</div>
							</div>
							<div class="col-md-6">
								<div class="mb-3">
									<label for="date_debut_carr" class="form-label"><?php echo trans('data.date_debut_carr'); ?> <strong style='color: red;'> *</strong></label>
									<?php echo Form::date('date_debut_carr',$item->date_debut_carr,["id"=>"date_debut_carr","class"=>"form-control" ,"required"=>"required" ,'autocomplete'=>'off' ,'placeholder'=>"Entrer Date debut" ]); ?>

								</div>
							</div>
							<div class="col-md-6">
								<div class="mb-3">
									<label for="date_fin_carr" class="form-label"><?php echo trans('data.date_fin_carr'); ?> <strong style='color: red;'> *</strong></label>
									<?php echo Form::date('date_fin_carr',$item->date_fin_carr,["id"=>"date_fin_carr","class"=>"form-control" ,"required"=>"required" ,'autocomplete'=>'off' ,'placeholder'=>"Entrer Date fin" ]); ?>

								</div>
							</div>
							<div class="col-md-6">
								<div class="mb-3">
									<label for="salaire_carr" class="form-label"><?php echo trans('data.salaire_carr'); ?> <strong style='color: red;'> *</strong></label>
									<?php echo Form::number('salaire_carr',$item->salaire_carr,["id"=>"salaire_carr","class"=>"form-control" ,"required"=>"required" ,'autocomplete'=>'off' ,'placeholder'=>"Entrer Salaire" ]); ?>

								</div>
							</div>
							<div class="col-md-6">
								<div class="mb-3">
									<label for="id_occupant" class="form-label"><?php echo trans('data.id_occupant'); ?> <strong style='color: red;'> *</strong></label>
									<?php $addUse = array(''=>'S&eacute;lectionnez un &eacute;l&eacute;ment'); $listid_occupant = $addUse + $listid_occupant->toArray();?>
									<?php echo Form::select('id_occupant',$listid_occupant ,$item->id_occupant,["id"=>"id_occupant","class"=>"form-select allselect" ,"required"=>"required"]); ?>

								</div>
							</div>
							<div class="col-12">
								<div class="text-end">
									<a href="<?php echo e(route('carriere.index')); ?>" class="btn btn-outline-dark waves-effect mr-10 rounded-pill">Fermer</a>
									<?php if(in_array('update_carriere',session('InfosAction'))): ?>
										<button type="submit" class="btn btn-success btn-label right rounded-pill"><i class="ri-edit-2-line label-icon align-middle fs-16 ms-2 rounded-pill"></i>Modifier</button>
									<?php endif; ?>
								</div>
							</div>
						</div><!--end row-->
					</form>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JS_content'); ?>
	<script src="<?php echo e(url('assets/js/jquery.min.js')); ?>" type="text/javascript"></script>
	<script type="text/javascript">
		// Écoutez les changements dans le premier combo(combo1)
		document.getElementById("type_destina").addEventListener("change", function() {
			ChargeDestinataire();
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SAGTECH\app_csm\resources\views/carriere/edit.blade.php ENDPATH**/ ?>