

<?php $__env->startSection('path_content'); ?>
	<?php if(sizeof($pathMenu) != 0): ?>
		<?php for($i=0; $i < count($pathMenu); $i++): ?>
			<li class="breadcrumb-item active"><a href="<?php echo e($pathMenu[$i]['lien']); ?>" class="kt-subheader__breadcrumbs-link"><?php echo e($pathMenu[$i]['titre']); ?></a></li>
		<?php endfor; ?>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="col-lg-12">
		<div class="card">
			<div class="card-header align-items-center d-flex">
				<h4 class="card-title mb-0 flex-grow-1"><?php echo e($titre); ?></h4>
				<div class="flex-shrink-0"><div class="form-check form-switch form-switch-right form-switch-md"><i class="<?php echo e($icone); ?>"></i></div></div>
			</div><!-- end card header -->
			<div class="card-body"><p class="text-muted"></p>
				<div class="live-preview"><strong><div class="msgAjouter"></div></strong>
					<form action="<?php echo e(route('archive.update',$item->id_archive)); ?>" method="post" id="form" class="row g-3 needs-validation" novalidate enctype='multipart/form-data'>
						<?php echo csrf_field(); ?>
						<?php echo method_field('PATCH'); ?>
							<div class="row">
							<?php if(session()->has('success') || session()->has('error')): ?><div class="col-md-12 mt-2"><div class="alert <?php echo session()->has('success') ? 'alert-success' : ''; ?> <?php echo session()->has('error') ? 'alert-danger' : ''; ?> alert-border-left alert-dismissible fade show" role="alert"><i title ="<?php echo session()->has('errorMsg')? session()->get('errorMsg') : ''; ?>" class=" <?php echo session()->has('success') ? 'ri-notification-off-line' : 'ri-error-warning-line'; ?> me-3 align-middle"></i> <strong>Infos </strong> - <?php echo session()->has('success') ? session()->get('success') : session()->get('error'); ?><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div></div><?php endif; ?>

							<div class="col-md-6">
								<div class="mb-3">
									<label for="ref_doc" class="form-label"><?php echo trans('data.ref_doc'); ?> <strong style='color: red;'> *</strong></label>
									<?php echo Form::text('ref_doc',$item->ref_doc,["id"=>"ref_doc","class"=>"form-control" ,"required"=>"required" ,'autocomplete'=>'off' ,'placeholder'=>"Entrer Reference" ]); ?>

								</div>
							</div>
							<div class="col-md-6">
								<div class="mb-3">
									<label for="sujet_doc" class="form-label"><?php echo trans('data.sujet_doc'); ?> <strong style='color: red;'> *</strong></label>
									<?php echo Form::text('sujet_doc',$item->sujet_doc,["id"=>"sujet_doc","class"=>"form-control" ,"required"=>"required" ,'autocomplete'=>'off' ,'placeholder'=>"Entrer Sujet" ]); ?>

								</div>
							</div>
							<div class="col-md-6">
								<div class="mb-3">
									<label for="type_doc" class="form-label"><?php echo trans('data.type_doc'); ?> <strong style='color: red;'> *</strong></label>
									<?php echo Form::select('type_doc',trans('entite.type_doc_Archive') ,$item->type_doc,["id"=>"type_doc","class"=>"form-select allselect" ,"required"=>"required"]); ?>

								</div>
							</div>
							<div class="col-md-6">
								<div class="mb-3">
									<label for="direc_id" class="form-label"><?php echo trans('data.direc_id'); ?> <strong style='color: red;'> *</strong></label>
									<?php $addUse = array(''=>'S&eacute;lectionnez un &eacute;l&eacute;ment'); $listdirec_id = $addUse + $listdirec_id->toArray();?>
									<?php echo Form::select('direc_id',$listdirec_id ,$item->direc_id,["id"=>"direc_id","class"=>"form-select allselect" ,"required"=>"required"]); ?>

								</div>
							</div>
							<div class="col-md-6">
								<div class="mb-3">
									<label for="fichier_doc" class="form-label"><?php echo trans('data.fichier_doc').' '.$item->fichier_doc; ?> <strong style='color: red;'> *</strong></label>
									<input class="form-control" type="file" id="fichier_doc" name="fichier_doc" <?php echo isset($item->fichier_doc) ? '' : 'required'; ?> >
								</div>
							</div>
							<div class="col-md-6">
								<div class="mb-3">
									<label for="statut_doc" class="form-label"><?php echo trans('data.statut_doc'); ?> <strong style='color: red;'> *</strong></label>
									<?php echo Form::select('statut_doc',trans('entite.statut_doc_Archive') ,$item->statut_doc,["id"=>"statut_doc","class"=>"form-select allselect" ,"required"=>"required"]); ?>

								</div>
							</div>
							<div class="col-12">
								<div class="text-end">
									<a href="<?php echo e(route('archive.index')); ?>" class="btn btn-outline-dark waves-effect mr-10">Fermer</a>
									<?php if(in_array('update_archive',session('InfosAction'))): ?>
										<button type="submit" class="btn btn-success btn-label right"><i class="ri-edit-2-line label-icon align-middle fs-16 ms-2"></i>Modifier</button>
									<?php endif; ?>
								</div>
							</div>
						</div><!--end row-->
					</form>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('JS_content'); ?>
    <script src="<?php echo e(url('assets/js/jquery.min.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SAGTECH\app_csm\resources\views/archive/edit.blade.php ENDPATH**/ ?>