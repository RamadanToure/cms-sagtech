


<?php $__env->startSection('path_content'); ?>
	<?php if(sizeof($pathMenu) != 0): ?>
		<?php for($i=0; $i < count($pathMenu); $i++): ?>
            <li class="breadcrumb-item active"><a href="<?php echo e($pathMenu[$i]['lien']); ?>" class="kt-subheader__breadcrumbs-link"><?php echo e($pathMenu[$i]['titre']); ?></a></li>
		<?php endfor; ?>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12">
        <div class="card">
            <div class="m-2">
                <?php if(session()->has('success') || session()->has('error')): ?><div class="col-md-12 mt-2"><div class="alert <?php echo session()->has('success') ? 'alert-success' : ''; ?> <?php echo session()->has('error') ? 'alert-danger' : ''; ?> alert-border-left alert-dismissible fade show" role="alert"><i title ="<?php echo session()->has('errorMsg')? session()->get('errorMsg') : ''; ?>" class=" <?php echo session()->has('success') ? 'ri-notification-off-line' : 'ri-error-warning-line'; ?> me-3 align-middle"></i> <strong>Infos </strong> - <?php echo session()->has('success') ? session()->get('success') : session()->get('error'); ?><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div></div><?php endif; ?>
            </div>

            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1"><?php echo e($titre); ?> ** Réf : <?php echo e($item->ref_cour); ?> ** Date de réception : <?php echo e(date('d/m/Y à H:i:s',strtotime($item->date_rece))); ?></h4>
                <div class="flex-shrink-0">
                    <div class="form-check form-switch form-switch-right form-switch-md">
                        <?php if($item->statut_cour=='tr'): ?>
                            <button type="button"  title='Transmettre le courrier au destinataire' data-id="<?php echo e($item->code_cour); ?>" class="btn btn-warning btn-sm rounded-pill btn-confirmer" data-bs-toggle="modal" ><i class=" bx bx-share"></i> Transmettre le courrier</button>
                        <?php endif; ?>
                        <a type="button" href="<?php echo e(url('listcourrieratraiter')); ?>" class="btn btn-dark btn-sm rounded-pill">Retour</a>
                    </div>
                </div>
            </div><!-- end card header -->
            <!-- Danger Alert -->
                <!-- <div class="alert alert-danger alert-dismissible alert-label-icon rounded-label fade show" role="alert">
                    <i class="ri-error-warning-line label-icon"></i><strong>Rejet </strong> - Motif : --
                </div> -->
            <!-- Secondary Alert -->
            <div class="alert alert-success alert-dismissible alert-label-icon rounded-label fade show" role="alert">
                <i class="ri-notification-off-line label-icon"></i><strong>Information sur l'expédteur </strong> - <?php echo e($item->expediteur->nom_expe .' ** Type : '.trans('entite.type_expediteur')[$item->expediteur->type_expe]); ?>

            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <!--end col-->
                    <!--end col-->
                    <div class="col-lg-4 col-6">
                        <p class="text-muted mb-2 text-uppercase fw-semibold"><?php echo e(trans('data.email_expe')); ?></p>
                        <h5 class="fs-14 mb-0"><span id="invoice-no"><?php echo e($item->expediteur->email_expe); ?></span></h5>
                    </div>
                    <!--end col-->
                    <div class="col-lg-8 col-6">
                        <p class="text-muted mb-2 text-uppercase fw-semibold"><?php echo e(trans('data.adres_expe')); ?></p>
                        <span class="badge badge-soft-success fs-11" id="payment-status"><?php echo e($item->expediteur->adres_expe); ?></span>
                    </div>
                </div>
            </div>
            
            <!-- Pièce jointes -->
            <div class="alert alert-primary alert-dismissible alert-label-icon rounded-label fade show" role="alert">
                <i class="ri-file-line label-icon"></i><strong>Détail sur le Courrier </strong> 
            </div>
            <div class=" align-items-center m-2 d-flex">
                <h4 class="card-title flex-grow-1"><?php echo e(trans('data.sujet_cour')); ?> <?php echo e($item->sujet_cour); ?></h4>
                <div class="flex-shrink-0">
                    <div class="form-check form-switch form-switch-right form-switch-md">
                        <button class="btn btn-primary btn-sm rounded-pill" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample"><i class="ri-eye-line"></i> Voir le courrier</button>
                    </div>
                </div>
            </div><!-- end card header -->
            <div class="card-body">
                <div class="row">
                    <!--end col-->
                    <div class="col-lg-6 col-12">
                        <p class="text-muted mb-2 text-uppercase fw-semibold"><?php echo e(trans('data.commentaire_cour')); ?></p>
                        <h5 class="fs-14 mb-0"><span id="total-amount"><?php echo e($item->commentaire_cour); ?></span></h5>
                    </div>
                    <!--end col-->
                </div>
            </div>
            <div class="collapse" id="collapseExample">
                <div class="card mb-0">
                    <div class="card-body">
                        <iframe style="width:100%;height: 600px;" src="<?php echo e(url('/assets/courrier/'.$item->piece_jointe_cour.'#zoom=100%&navpanes=0')); ?>"></iframe>
                    </div>
                </div>
            </div>
            <!-- Info Alert -->
            <div class="alert alert-info alert-dismissible alert-label-icon rounded-label fade show" role="alert">
                <i class="ri-file-list-3-line label-icon"></i><strong>Parcours de traitement</strong>
            </div>
            <?php if(count($traceCourrier) != 0): ?>
                <div class="card-body p-4">
                    <div class="table-responsive">
                        <table class="table table-borderless text-center table-nowrap align-middle mb-0">
                            <thead>
                                <tr class="table-active">
                                    <th scope="col" style="width: 50px;">N°</th>
                                    <th class="text-start">Transféré à</th>
                                    <th class="text-start">Par</th>
                                    <th scope="col">Etat</th>
                                    <th scope="col">Fichier réponse</th>
                                </tr>
                            </thead>
                            <?php $i=0; ?>
                            <tbody id="products-list">
                                <?php $__currentLoopData = $traceCourrier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $i++; ?>
                                <tr>
                                    <th scope="row"><?php echo e($i); ?></th>
                                    <td class="text-start"><?php echo e(trans('entite.type_destinataire')[$line->type_destina].' : '.$line->fonction($line->type_destina,$line->id_desti)); ?></td>
                                    <td class="text-start"><?php echo e(isset($line->users_g) ? $line->users_g->name : '--'); ?></td>
                                    <td><?php echo e(trans('entite.statut_courrier')[$line->etat_trce]); ?></td>
                                    <td>
                                        <?php if($line->fichier_reponse): ?>
                                            <button class="btn btn-primary btn-sm rounded-pill" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample<?php echo e($line->id_trce); ?>" aria-expanded="false" aria-controls="collapseExample<?php echo e($line->id_trce); ?>"><i class="ri-eye-line"></i> Voir la réponse</button>
                                        <?php else: ?> -- <?php endif; ?>
                                    </td>
                                </tr>
                                <div class="collapse" id="collapseExample<?php echo e($line->id_trce); ?>">
                                    <?php echo e(trans('data.note_trce')); ?> : <?php echo e($line->note_trce); ?>

                                    <div class="card mb-0">
                                        <div class="card-body">
                                            <iframe style="width:100%;height: 600px;" src="<?php echo e(url('/assets/courrier/'.$line->fichier_reponse.'#zoom=100%&navpanes=0')); ?>"></iframe>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!--end table-->
                    </div>
                </div>
            <?php else: ?> 
                <div Class="alert alert-info m-4"><strong>Info! </strong> Aucun parcours tracé</div>
            <?php endif; ?>
        </div>
    </div>
	<div><div class="modal fade bs-example-modal-center" id="kt_confirmer_4" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" role="dialog" >
		<div class="modal-dialog modal-dialog-centered"></div>
	</div></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JS_content'); ?>
	<script src="<?php echo e(url('assets/js/jquery.min.js')); ?>" type="text/javascript"></script>
	<script type="text/javascript">
		
		$(document).on('click', '.btn-confirmer', function () {
			id = $(this).data("id");
			$.ajax({url : '<?php echo e(url("courrier/AffichePopConfirmerExp/")); ?>/'+id,type : 'GET',dataType : 'html',
				success : function(code_html, statut){$("#kt_confirmer_4 .modal-dialog").html(code_html);$("#kt_confirmer_4").modal('show');}
			});
		});
	</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SAGTECH\app_csm\resources\views/courrier/consulter.blade.php ENDPATH**/ ?>