<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php if(count($list) != 0): ?>
    <table class="table table-striped table-bordered table-nowrap">
        <thead>
            <tr>
                <th scope="col"><?php echo e(trans('data.menu_icon')); ?></th>
                <th scope="col"><?php echo e(trans('data.libelle_menu')); ?></th>
                <th scope="col"><?php echo e(trans('data.titre_page')); ?></th>
                <th scope="col"><?php echo e(trans('data.route')); ?></th>
                <th scope="col"><?php echo e(trans('data.architecture')); ?></th>
                <?php if(in_array('update_menu',session('InfosAction')) || in_array('delete_menu',session('InfosAction')) || in_array('add_action',session('InfosAction'))): ?>
                    <th class="text-center"> Actions</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listgiwu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center icon-demo-content"><i class="<?php echo e($listgiwu->menu_icon); ?>"></i></td>
                    <td><?php echo e($listgiwu->libelle_menu); ?></td>
                    <td><?php echo e($listgiwu->titre_page); ?></td>
                    <td><?php echo e($listgiwu->route); ?></td>
                    <td><?php echo e($listgiwu->architecture); ?></td>
                    <?php if(in_array('update_menu',session('InfosAction')) || in_array('delete_menu',session('InfosAction')) || in_array('add_action',session('InfosAction'))): ?>
                        <td class="text-center">
                            <?php if(in_array('update_menu',session('InfosAction'))): ?>
                                <a href="<?php echo e(route('menu.edit',$listgiwu->id_menu)); ?>" title='Modifier' class="btn btn-success btn-sm  waves-effect waves-light"><i class="ri-edit-2-line"></i></a>
                            <?php endif; ?>
                            <?php if(in_array('delete_menu',session('InfosAction'))): ?>
                                <button type="button"  title='Supprimer' data-id="<?php echo e($listgiwu->id_menu); ?>" class="btn btn-danger btn-sm  waves-effect waves-light btn-delete" data-bs-toggle="modal" ><i class="ri-delete-bin-6-line"></i></button>
                            <?php endif; ?>
                            <?php if(in_array('add_action',session('InfosAction'))): ?>
                                <button type="button" title='Actions' data-id="<?php echo e($listgiwu->id_menu); ?>" class="btn btn-sm btn-warning waves-effect waves-light btn-action"  data-toggle="modal"><i class="ri-add-line"></i></button>
                            <?php endif; ?>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo $list->appends([
        'query'=>(isset($_GET['query'])?$_GET['query']:'')
        ])->links(); ?>

<?php else: ?>
	<div class="alert alert-info"><strong>Info! </strong> <?php echo trans('data.AucunInfosTrouve'); ?> </div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\SAGTECH\app_csm\resources\views/menu/index-search.blade.php ENDPATH**/ ?>