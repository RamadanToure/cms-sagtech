<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php if(count($list) != 0): ?>
	<table class="table table-striped table-bordered table-nowrap">
		<thead><tr>
			<?php if(in_array('update_archive',session('InfosAction')) || in_array('delete_archive',session('InfosAction')) ): ?>
				<th class="text-center"> Actions</th>
			<?php endif; ?>
			<th scope="col" ><?php echo trans('data.ref_doc'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.fichier_doc'); ?></th>
			<!-- <th scope="col" ><?php echo trans('data.code_doc'); ?></th> -->
			<th scope="col" ><?php echo trans('data.sujet_doc'); ?></th>
			<th scope="col" ><?php echo trans('data.type_doc'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.direc_id'); ?></th>
			<th scope="col" ><?php echo trans('data.statut_doc'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.init_id'); ?></th>
		</tr></thead>
		<tbody>
			<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listgiwu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<?php if(in_array('update_archive',session('InfosAction')) || in_array('delete_archive',session('InfosAction')) ): ?>
						<td class="text-center">
							<?php if(in_array('update_archive',session('InfosAction'))): ?>
								<a href="<?php echo e(route('archive.edit',$listgiwu->id_archive)); ?>" title='Modifier' class="btn btn-success btn-sm  waves-effect waves-light"><i class="ri-edit-2-line"></i></a>
							<?php endif; ?>
							<?php if(in_array('delete_archive',session('InfosAction'))): ?>
								<button type="button"  title='Supprimer' data-id="<?php echo e($listgiwu->id_archive); ?>" class="btn btn-danger btn-sm  waves-effect waves-light btn-delete" data-bs-toggle="modal" ><i class="ri-delete-bin-6-line"></i></button>
							<?php endif; ?>
						</td>
					<?php endif; ?>
					<td><?php echo $listgiwu->ref_doc; ?></td>
					<td class="text-center">
						<?php if($listgiwu->fichier_doc): ?>
							<a href='<?php echo e("assets/courrier/".$listgiwu->fichier_doc); ?>' title="<?php echo $listgiwu->fichier_doc; ?>" target="_blank" class="badge bg-success">Ouvrir</a>
						<?php else: ?> <span class="badge bg-danger">Aucun</a>  <?php endif; ?>
					</td>
					<!-- <td><?php echo $listgiwu->code_doc; ?></td> -->
					<td><?php echo $listgiwu->sujet_doc; ?></td>
					<td><?php echo trans('entite.type_doc_Archive')[$listgiwu->type_doc]; ?></td>
					<td title="<?php echo e(isset($listgiwu->direction) ? $listgiwu->direction->lib_direc : trans('data.not_found')); ?>"><?php echo isset($listgiwu->direction) ? $listgiwu->direction->code_direc : trans('data.not_found'); ?></td>
					<td><?php echo trans('entite.statut_doc_Archive')[$listgiwu->statut_doc]; ?></td>
					<td><?php echo isset($listgiwu->users_g) ? $listgiwu->users_g->name." ".$listgiwu->users_g->prenom : trans('data.not_found'); ?></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	
	<?php echo $list->appends(['query'=>(isset($_GET['query'])?$_GET['query']:'') ])->links(); ?>

<?php else: ?>
	<div Class="alert alert-info"><strong>Info! </strong> <?php echo trans('data.AucunInfosTrouve'); ?> </div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\SAGTECH\app_csm\resources\views/archive/index-search.blade.php ENDPATH**/ ?>